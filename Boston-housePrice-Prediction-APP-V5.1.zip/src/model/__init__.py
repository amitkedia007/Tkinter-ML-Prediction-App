# models/__init__.py

from .multiple_linear_regression import MultipleLinearRegression
# from .svr import SVR
# from .decision_tree import DecisionTree
from .ridge_regression import RidgeRegression
