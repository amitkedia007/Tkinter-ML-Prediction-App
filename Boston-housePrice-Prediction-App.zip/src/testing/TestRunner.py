# Automates running of tests
