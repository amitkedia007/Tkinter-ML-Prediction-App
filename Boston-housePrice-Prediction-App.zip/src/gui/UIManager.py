import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import pandas as pd
from pandas.api.types import is_numeric_dtype
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import seaborn as sns

class UIManager:
    def __init__(self, master):
        self.master = master
        self.master.title('Data Analysis Application')
        self.master.geometry('1200x800')
        self.dataset = None
        self.target_variable = None
        self.scaler = StandardScaler()
        self.initialize_ui()

    def initialize_ui(self):
                # Frame for Data Loading
        frame_load = tk.Frame(self.master)
        frame_load.pack(fill=tk.X, padx=5, pady=5)

        self.btn_load = tk.Button(frame_load, text='Load Dataset', command=self.load_dataset)
        self.btn_load.pack(side=tk.LEFT, padx=5, pady=5)

        # Frame for Data Description
        frame_description = tk.LabelFrame(self.master, text='Data Description')
        frame_description.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.txt_description = tk.Text(frame_description)
        self.txt_description.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Frame for Preprocessing
        frame_preprocess = tk.Frame(self.master)
        frame_preprocess.pack(fill=tk.X, padx=5, pady=5)

        self.btn_convert_categorical = tk.Button(frame_preprocess, text='Convert Categorical', command=self.convert_categorical)
        self.btn_convert_categorical.pack(side=tk.LEFT, padx=5, pady=5)

        self.btn_scale = tk.Button(frame_preprocess, text='Scale Data', command=self.scale_data)
        self.btn_scale.pack(side=tk.LEFT, padx=5, pady=5)

        self.btn_drop_columns = tk.Button(frame_preprocess, text='Drop Columns', command=self.drop_columns)
        self.btn_drop_columns.pack(side=tk.LEFT, padx=5, pady=5)

        self.btn_fill_mean = tk.Button(frame_preprocess, text='Fill Mean', command=self.fill_mean)
        self.btn_fill_mean.pack(side=tk.LEFT, padx=5, pady=5)

        self.btn_fill_unknown = tk.Button(frame_preprocess, text='Fill Unknown', command=self.fill_unknown)
        self.btn_fill_unknown.pack(side=tk.LEFT, padx=5, pady=5)

        # Frame for Model Selection
        frame_model_select = tk.Frame(self.master)
        frame_model_select.pack(fill=tk.X, padx=5, pady=5)

        tk.Label(frame_model_select, text="Select Model:").pack(side=tk.LEFT, padx=5, pady=5)
        
        self.model_var = tk.StringVar()
        self.model_options = ['Linear Regression', 'Ridge Regression', 'SVM', 'KNN']
        self.model_dropdown = ttk.Combobox(frame_model_select, textvariable=self.model_var, values=self.model_options)
        self.model_dropdown.pack(side=tk.LEFT, padx=5, pady=5)
        self.model_dropdown.current(0)  # Set default model to Linear Regression
        
        self.btn_go = tk.Button(frame_model_select, text='GO', command=self.train_model)
        self.btn_go.pack(side=tk.LEFT, padx=5, pady=5)
        
        # Frame for Parameter Selection (example for Linear Regression)
        frame_params = tk.Frame(self.master)
        frame_params.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Label(frame_params, text="Select Parameters:").pack(side=tk.LEFT, padx=5, pady=5)
        
        # Parameter 1 example: Alpha for Ridge Regression
        tk.Label(frame_params, text="Alpha:").pack(side=tk.LEFT, padx=5, pady=5)
        self.alpha_var = tk.DoubleVar(value=1.0)
        self.alpha_entry = tk.Entry(frame_params, textvariable=self.alpha_var)
        self.alpha_entry.pack(side=tk.LEFT, padx=5, pady=5)
        
        # Parameter 2 example: Kernel for SVM
        tk.Label(frame_params, text="Kernel:").pack(side=tk.LEFT, padx=5, pady=5)
        self.kernel_var = tk.StringVar()
        self.kernel_options = ['linear', 'poly', 'rbf', 'sigmoid']
        self.kernel_dropdown = ttk.Combobox(frame_params, textvariable=self.kernel_var, values=self.kernel_options)
        self.kernel_dropdown.pack(side=tk.LEFT, padx=5, pady=5)
        self.kernel_dropdown.current(0)  # Set default kernel to 'linear'



    # Add more methods to handle UI actions

    def load_dataset(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            try:
                self.dataset = pd.read_csv(file_path)
                self.update_dataset_info()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load the file\n{e}")

    def update_dataset_info(self):
        """ Update the UI with dataset information. """
        if self.dataset is not None:
            # Clear the previous content
            self.txt_description.delete('1.0', tk.END)
            
            # Constructing the dataset description message
            info_text = f"Dataset Loaded:\n\n"
            info_text += f"Number of Rows: {self.dataset.shape[0]}\n"
            info_text += f"Number of Columns: {self.dataset.shape[1]}\n\n"
            info_text += "Column Details:\n"
            for column in self.dataset.columns:
                info_text += f"{column} ({self.dataset[column].dtype})\n"
            
            # Optionally, display the first 5 rows of the dataset
            info_text += "\nFirst 5 rows of the dataset:\n"
            info_text += self.dataset.head().to_string() + "\n"
            
            # Update the Text widget with this information
            self.txt_description.insert(tk.END, info_text)

    def set_target(self):
            """ Set the target variable for prediction. """
            if self.dataset is None:
                messagebox.showwarning('Warning', 'No dataset loaded. Please load a dataset first.')
                return
            
            # Pop up a new window to select the target variable from a list of dataset columns
            target_window = tk.Toplevel(self.master)
            target_window.title('Select Target Variable')
            
            tk.Label(target_window, text="Choose the target variable:").pack(padx=10, pady=10)
            
            # Dropdown menu to select the target column from the dataset columns
            columns = self.dataset.columns.tolist()
            self.target_var = tk.StringVar(target_window)
            target_dropdown = ttk.Combobox(target_window, textvariable=self.target_var, values=columns)
            target_dropdown.pack(padx=10, pady=10)
            
            # Button to set the selected column as the target variable
            set_button = tk.Button(target_window, text="Set Target", command=lambda: self.assign_target(target_dropdown.get()))
            set_button.pack(padx=10, pady=20)
            
    def assign_target(self, target):
        """ Helper function to assign the target variable. """
        if target in self.dataset.columns:
            self.target_variable = target
            messagebox.showinfo('Info', f'Set "{self.target_variable}" as the target variable.')
        else:
            messagebox.showerror('Error', 'Please select a valid target variable.')


    def convert_categorical(self):
        """ Convert categorical features to numeric using label encoding. """
        if self.dataset is None:
            messagebox.showwarning('Warning', 'No dataset loaded. Please load a dataset first.')
            return
        
        # Iterate over each column and check if it is categorical (non-numeric)
        for column in self.dataset.columns:
            if not is_numeric_dtype(self.dataset[column]):
                # Use factorize to convert the categorical data to an enumerated type
                self.dataset[column], _ = pd.factorize(self.dataset[column])
                
        # Update the UI to show that the conversion has taken place
        self.update_dataset_info()
        messagebox.showinfo('Info', 'All categorical variables have been converted to numeric.')

    def scale_data(self):
        """ Scale data using StandardScaler. """
        if self.dataset is None:
            messagebox.showwarning('Warning', 'No dataset loaded. Please load a dataset first.')
            return
        
        if self.target_variable is None:
            messagebox.showwarning('Warning', 'No target variable set. Please set the target variable first.')
            return

        # Separating out the features and target variable
        features = self.dataset.drop(self.target_variable, axis=1)
        target = self.dataset[self.target_variable]
        
        # Ensuring that only numeric data is scaled
        numeric_features = features.select_dtypes(include=['int64', 'float64'])

        # Initializing the StandardScaler
        scaler = StandardScaler()

        # Fitting the scaler to the features and transforming them
        scaled_features = scaler.fit_transform(numeric_features)
        
        # Replace original numeric features with scaled values
        for (column, data) in zip(numeric_features.columns, scaled_features.T):
            self.dataset[column] = data

        # Inform the user and update the data description in the UI
        self.update_dataset_info()
        messagebox.showinfo('Info', 'Numeric features have been scaled using StandardScaler.')


    def drop_columns(self):
        """ Drop selected columns from the dataset. """
        if self.dataset is None:
            messagebox.showwarning('Warning', 'No dataset loaded. Please load a dataset first.')
            return

        # This implementation assumes you have a way for the user to select columns to drop,
        # such as a list of checkboxes or a multi-select listbox. The selected_columns
        # should be a list of column names to drop.
        selected_columns = self.get_columns_to_drop()  # This should be defined based on your UI elements

        if not selected_columns:
            messagebox.showwarning('Warning', 'No columns selected to drop.')
            return

        # Drop the columns from the dataset
        self.dataset.drop(columns=selected_columns, inplace=True)

        # Update the UI to reflect changes
        self.update_dataset_info()
        messagebox.showinfo('Info', f'Columns {", ".join(selected_columns)} have been dropped from the dataset.')

    def get_columns_to_drop(self):
        """ 
        Placeholder for the method that retrieves the list of selected columns to drop. 
        This will depend on your UI design, whether it's checkboxes, a listbox, etc.
        """
        # This is just a placeholder. You would need to implement this method
        # to return the actual list of columns selected by the user in the UI.
        return []


    def fill_mean(self):
        """ Fill missing values in numeric columns with mean. """
        if self.dataset is None:
            messagebox.showwarning('Warning', 'No dataset loaded. Please load a dataset first.')
            return
        
        # Iterate over each column in the dataset
        for column in self.dataset.select_dtypes(include=[np.number]).columns:
            if self.dataset[column].isnull().sum() > 0:  # Check for missing values
                # Calculate the mean of the column
                mean_value = self.dataset[column].mean()
                
                # Fill the missing values with the mean
                self.dataset[column].fillna(mean_value, inplace=True)
        
        # Update the dataset information in the UI
        self.update_dataset_info()
        messagebox.showinfo('Info', 'Missing values in numeric columns have been filled with the mean.')


    def fill_unknown(self):
        """ Fill missing values in non-numeric columns with a placeholder. """
        if self.dataset is None:
            messagebox.showwarning('Warning', 'No dataset loaded. Please load a dataset first.')
            return
        
        placeholder = "Unknown"  # Placeholder value for missing entries
        non_numeric_columns = self.dataset.select_dtypes(exclude=[np.number]).columns

        for column in non_numeric_columns:
            if self.dataset[column].isnull().sum() > 0:  # Check for missing values
                # Fill missing values with the placeholder
                self.dataset[column].fillna(placeholder, inplace=True)
        
        # Update the UI to reflect these changes
        self.update_dataset_info()
        messagebox.showinfo('Info', 'Missing values in non-numeric columns have been filled with "{}".'.format(placeholder))


    def plot_scatter(self):
        """Plot a scatter plot."""
        # Example: Plotting the first two numeric columns against each other
        if self.dataset is None or self.dataset.select_dtypes(include=[np.number]).shape[1] < 2:
            messagebox.showerror("Error", "Dataset is not loaded or does not have enough numeric columns.")
            return
        
        new_window = tk.Toplevel(self.master)
        new_window.title("Scatter Plot")

        fig, ax = plt.subplots(figsize=(5, 4))
        numeric_cols = self.dataset.select_dtypes(include=[np.number]).columns
        sns.scatterplot(x=self.dataset[numeric_cols[0]], y=self.dataset[numeric_cols[1]], ax=ax)

        canvas = FigureCanvasTkAgg(fig, master=new_window)  # A tk.DrawingArea.
        canvas.draw()
        canvas.get_tk_widget().pack()

    def plot_line(self):
        """Plot a line chart."""
        # This assumes your dataset's first column is suitable as an x-axis (e.g., time series data)
        if self.dataset is None or self.dataset.select_dtypes(include=[np.number]).shape[1] < 2:
            messagebox.showerror("Error", "Dataset is not loaded or does not have enough numeric columns.")
            return
        
        new_window = tk.Toplevel(self.master)
        new_window.title("Line Chart")

        fig, ax = plt.subplots(figsize=(5, 4))
        numeric_cols = self.dataset.select_dtypes(include=[np.number]).columns
        self.dataset.plot(x=numeric_cols[0], y=numeric_cols[1:], ax=ax, legend=True)

        canvas = FigureCanvasTkAgg(fig, master=new_window)
        canvas.draw()
        canvas.get_tk_widget().pack()

    def plot_histogram(self):
        """Plot a histogram."""
        # Example: Plotting a histogram of the first numeric column
        if self.dataset is None or not self.dataset.select_dtypes(include=[np.number]).columns.any():
            messagebox.showerror("Error", "Dataset is not loaded or does not have numeric columns.")
            return
        
        new_window = tk.Toplevel(self.master)
        new_window.title("Histogram")

        fig, ax = plt.subplots(figsize=(5, 4))
        sns.histplot(self.dataset[self.dataset.select_dtypes(include=[np.number]).columns[0]], kde=True, ax=ax)

        canvas = FigureCanvasTkAgg(fig, master=new_window)
        canvas.draw()
        canvas.get_tk_widget().pack()

    def plot_heatmap(self):
        """Plot a heatmap."""
        # Ensure there's enough data for a correlation matrix
        if self.dataset is None or self.dataset.select_dtypes(include=[np.number]).shape[1] < 2:
            messagebox.showerror("Error", "Dataset is not loaded or does not have enough numeric columns for correlation.")
            return
        
        new_window = tk.Toplevel(self.master)
        new_window.title("Heatmap")

        fig, ax = plt.subplots(figsize=(5, 4))
        corr = self.dataset.select_dtypes(include=[np.number]).corr()
        sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", ax=ax)

        canvas = FigureCanvasTkAgg(fig, master=new_window)
        canvas.draw()
        canvas.get_tk_widget().pack()


    def train_model(self):
        """ Train the selected model. """
        if self.dataset is None or self.target_variable is None:
            messagebox.showerror("Error", "Dataset not loaded or target variable not set.")
            return
        
        # Prepare data
        X = self.dataset.drop(self.target_variable, axis=1)
        y = self.dataset[self.target_variable]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Select and train the model
        model = None
        if self.model_var.get() == 'Linear Regression':
            model = LinearRegression()
        elif self.model_var.get() == 'Ridge Regression':
            model = Ridge(alpha=1.0)  # Example: using default alpha, this could be set dynamically
        elif self.model_var.get() == 'SVM':
            model = SVR(kernel='linear')  # Example: using linear kernel, could be set dynamically
        elif self.model_var.get() == 'KNN':
            model = KNeighborsRegressor(n_neighbors=5)  # Example: using 5 neighbors, could be set dynamically
        
        if model is not None:
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            
            # Evaluate the model
            mse = mean_squared_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)
            
            results = f"MSE: {mse}\nR2: {r2}"
            self.show_results_window(results)
        else:
            messagebox.showerror("Error", "Model selection failed.")

    def show_results_window(self, results):
        """ Show results in a new window. """
        results_window = tk.Toplevel(self.master)
        results_window.title("Model Training Results")
        
        tk.Label(results_window, text="Training Results").pack(pady=10)
        tk.Text(results_window, height=10, width=50).pack(pady=10).insert(tk.END, results)


if __name__ == "__main__":
    root = tk.Tk()
    app = UIManager(root)
    root.mainloop()
